﻿========================================================================
    APLICACIÓN DE CONSOLA: addexample Información general 
    del proyecto
========================================================================

AppWizard ha creado esta aplicación addexample.

Este archivo contiene un resumen de lo que encontrará en todos los 
archivos que componen la addexample aplicación.


addexample.vcproj
    Éste es el archivo de proyecto principal para los proyectos de VC++ 
    generados mediante un Asistente para aplicaciones.
    Contiene información acerca de la versión de Visual C++ que generó 
    el archivo e información acerca de las plataformas, configuraciones 
    y características del proyecto seleccionadas con el Asistente para 
    aplicaciones.

addexample.cpp
    Ésta es la aplicación principal del archivo de código fuente.

/////////////////////////////////////////////////////////////////////////////
Otros archivos estándar:

StdAfx.h, StdAfx.cpp
    Estos archivos se utilizan para generar un archivo de encabezado 
    precompilado (PCH) denominado addexample.pch y un archivo de 
    tipos precompilados denominado StdAfx.obj.

/////////////////////////////////////////////////////////////////////////////
Otras notas:

AppWizard usa comentarios "TODO:" para indicar las partes del código fuente 
que debería agregar o personalizar.

/////////////////////////////////////////////////////////////////////////////
